<?php

namespace App\Form;

use App\Entity\Avis;
use App\Entity\Evenement;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AvisType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('TypeAvis')
            ->add('Note')
            ->add('NomClient')
            ->add('Email')
            ->add('Des')
            ->add('Titre', EntityType::class, [
                'class' => Evenement::class,
                'choice_label' => 'Titre'
            ])
            ->add('DateEvent', EntityType::class, [
                'class' => Evenement::class,
                'choice_label' => 'DateEvent'
            ])->add('add',SubmitType::class,[
                'attr' => ['class' => 'btn btn-theme'],
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Avis::class,
        ]);
    }
}
