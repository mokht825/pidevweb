<?php

namespace App\Controller;

use App\Entity\Avis;
use App\Entity\Evenement;
use App\Form\AvisType;
use App\Form\EvenementType;
use App\Repository\AvisRepository;
use App\Repository\CoachRepository;
use App\Repository\EvenementRepository;
use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelHigh;
use Endroid\QrCode\Label\Alignment\LabelAlignmentCenter;
use Endroid\QrCode\Label\Font\NotoSans;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;
use Swift_Mailer;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * @Route("/evenement")
 */
class EvenementController extends AbstractController
{

    /**
     * @param EvenementRepository $repository
     * @param Request $request
     * @return Response
     * @Route("/search",name="search")
     *
     *
     */
    public function searchEvenement(EvenementRepository $repository, Request $request)
    {


        $requestString=$request->get('searchValue');
        if(strlen($requestString)>0) {
            $evenement = $repository->findEvenementByNom($requestString);

        }
        else
        { $evenement = $repository->findAll();}

        $encoders = [new XmlEncoder(), new JsonEncoder()];
        $normalizers = [new ObjectNormalizer()];

        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent = $serializer->serialize($evenement, 'json');


        $response = new Response(json_encode($jsonContent));
        $response->headers->set('Content-Type', 'application/json; charset=utf-8');

        return $response;
    }
    /**
     * @Route("/", name="evenement_index", methods={"GET"})
     */
    public function index(EvenementRepository $evenementRepository): Response
    {
        return $this->render('admin/evenement/index.html.twig', [
            'evenements' => $evenementRepository->findAll(),
        ]);
    }

    /**
     * @Route("/EvTrier", name="evenement_trier", methods={"GET"})
     */
    public function EvenementTrier(EvenementRepository $evenementRepository): Response
    {
        return $this->render('admin/evenement/index.html.twig', [
            'evenements' => $evenementRepository->TrierParDate(),
        ]);
    }
    /**
     * @Route("/EvDispo", name="evenement_dispo", methods={"GET"})
     */
    public function EvenementDispo(EvenementRepository $evenementRepository): Response
    {
        return $this->render('admin/evenement/index.html.twig', [
            'evenements' => $evenementRepository->LesEvenementsDisponible(),
        ]);
    }
    /**
     * @Route("/Client", name="evenement_indexClient", methods={"GET"})
     */
    public function indexC(EvenementRepository $evenementRepository): Response
    {
        return $this->render('evenement/index.html.twig', [
            'evenements' => $evenementRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="evenement_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $evenement = new Evenement();
        $form = $this->createForm(EvenementType::class, $evenement);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $file = $form->get('image')->getData();

            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            try{
                $file->move(
                    $this->getParameter('images_directory'),
                    $fileName
                );
            } catch (FileException $e){

            }
            $entityManager = $this->getDoctrine()->getManager();
            $evenement->setImage($fileName);
            $entityManager->persist($evenement);
            $entityManager->flush();
            $result = Builder::create()
                ->writer(new PngWriter())
                ->writerOptions([])
                ->data('TITLE: '.$evenement->getDesEvent())
                ->encoding(new Encoding('UTF-8'))
                ->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
                ->size(300)
                ->margin(10)
                ->roundBlockSizeMode(new RoundBlockSizeModeMargin())
                ->labelText('Scan the event')
                ->labelFont(new NotoSans(20))
                ->labelAlignment(new LabelAlignmentCenter())
                ->build();
            header('Content-Type: '.$result->getMimeType());

            $result->saveToFile($this->getParameter('images_directory').'/'.$evenement->getId().'.png');

            return $this->redirectToRoute('evenement_index');
        }

        return $this->render('admin/evenement/new.html.twig', [
            'evenement' => $evenement,
            'form' => $form->createView(),
        ]);
    }


    /**
     * @Route("/{id}", name="evenement_show", methods={"GET"})
     */
    public function show(Evenement $evenement): Response

    {

        return $this->render('admin/evenement/show.html.twig', [
            'evenement' => $evenement,

        ]);
    }
    /**
     * @Route("/Client/{id}", name="evenement_showClient", methods={"GET","POST"})
     */
    public function showC(Evenement $evenement,AvisRepository $avisRepository,Request $request): Response
    {
        $avi = new Avis();
        $form = $this->createForm(AvisType::class, $avi);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $Eid=$avi->getDateEvent()->getId();
            $entityManager->persist($avi);
            $entityManager->flush();

            return $this->redirectToRoute('evenement_showClient', [ 'id' => $Eid]);
        }

        return $this->render('evenement/show.html.twig', [
            'avi' => $avi,
            'form' => $form->createView(),
            'evenement' => $evenement,
            'avis' => $avisRepository->findAll(),
        ]);
    }



    /**
     * @Route("/{id}/edit", name="evenement_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Evenement $evenement): Response
    {
        $form = $this->createForm(EvenementType::class, $evenement);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $file = $form->get('image')->getData();

            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            try{
                $file->move(
                    $this->getParameter('images_directory'),
                    $fileName
                );
            } catch (FileException $e){

            }
            $evenement->setImage($fileName);
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('evenement_index');
        }

        return $this->render('admin/evenement/edit.html.twig', [
            'evenement' => $evenement,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="evenement_delete", methods={"POST"})
     */
    public function delete(Request $request, Evenement $evenement): Response
    {
        if ($this->isCsrfTokenValid('delete'.$evenement->getId(), $request->request->get('_token'))) {


            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($evenement);
            $entityManager->flush();

        }

        return $this->redirectToRoute('evenement_index');
    }
}
