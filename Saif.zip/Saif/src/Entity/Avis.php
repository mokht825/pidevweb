<?php

namespace App\Entity;

use App\Repository\AvisRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Constraints\EmailValidator;

/**
 * @ORM\Entity(repositoryClass=AvisRepository::class)
 */
class Avis
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @Assert\NotBlank(message="merci de saisir le type de votre Avis")
     * @ORM\Column(type="string", length=255)
     */
    private $TypeAvis;

    /**
     * @ORM\Column(type="integer")
     */
    private $Note;

    /**
     * @ORM\Column(type="string", length=255)
     * @Assert\NotBlank(message="merci de saisir Votre Nom")
     */
    private $NomClient;

    /**
     * @ORM\Column(type="string", length=255)
     * @Assert\Email(  message = "The email '{{ value }}' is not a valid email.")
     */
    private $Email;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Des;

    /**
     * @ORM\ManyToOne(targetEntity=Evenement::class)
     * @ORM\JoinColumn(onDelete="CASCADE")
     */
    private $Titre;

    /**
     * @ORM\ManyToOne(targetEntity=Evenement::class)
     * @ORM\JoinColumn(onDelete="CASCADE")
     */
    private $DateEvent;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTypeAvis(): ?string
    {
        return $this->TypeAvis;
    }

    public function setTypeAvis(string $TypeAvis): self
    {
        $this->TypeAvis = $TypeAvis;

        return $this;
    }

    public function getNote(): ?int
    {
        return $this->Note;
    }

    public function setNote(int $Note): self
    {
        $this->Note = $Note;

        return $this;
    }

    public function getNomClient(): ?string
    {
        return $this->NomClient;
    }

    public function setNomClient(string $NomClient): self
    {
        $this->NomClient = $NomClient;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->Email;
    }

    public function setEmail(string $Email): self
    {
        $this->Email = $Email;

        return $this;
    }

    public function getDes(): ?string
    {
        return $this->Des;
    }

    public function setDes(string $Des): self
    {
        $this->Des = $Des;

        return $this;
    }

    public function getTitre(): ?Evenement
    {
        return $this->Titre;
    }

    public function setTitre(?Evenement $Titre): self
    {
        $this->Titre = $Titre;

        return $this;
    }

    public function getDateEvent(): ?Evenement
    {
        return $this->DateEvent;
    }

    public function setDateEvent(?Evenement $DateEvent): self
    {
        $this->DateEvent = $DateEvent;

        return $this;
    }
}
