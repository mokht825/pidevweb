<?php

namespace App\Entity;

use App\Repository\EvenementRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass=EvenementRepository::class)
 */
class Evenement
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @Assert\NotBlank(message="merci de donner un titre pour l'évenement")
     */
    private $Titre;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $DesEvent;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $DateEvent;

    /**
     * @ORM\Column(type="integer")
     */
    private $Prix;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Adresse;

    /**
     * @ORM\Column(type="integer")
     */
    private $NbrTotal;

    /**
     * @ORM\Column(type="integer")
     */
    private $NbrRestant;

    /**
     * @ORM\Column(type="string", length=255)
     * @Assert\NotBlank(message="merci de choisir l'image d'Evenement adequate")
     * @Assert\File(mimeTypes={"image/jpeg","image/gif","image/png"})
     */
    private $image;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitre(): ?string
    {
        return $this->Titre;
    }

    public function setTitre(string $Titre): self
    {
        $this->Titre = $Titre;

        return $this;
    }

    public function getDesEvent(): ?string
    {
        return $this->DesEvent;
    }

    public function setDesEvent(string $DesEvent): self
    {
        $this->DesEvent = $DesEvent;

        return $this;
    }

    public function getDateEvent(): ?string
    {
        return $this->DateEvent;
    }

    public function setDateEvent(string $DateEvent): self
    {
        $this->DateEvent = $DateEvent;

        return $this;
    }

    public function getPrix(): ?int
    {
        return $this->Prix;
    }

    public function setPrix(int $Prix): self
    {
        $this->Prix = $Prix;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->Adresse;
    }

    public function setAdresse(string $Adresse): self
    {
        $this->Adresse = $Adresse;

        return $this;
    }

    public function getNbrTotal(): ?int
    {
        return $this->NbrTotal;
    }

    public function setNbrTotal(int $NbrTotal): self
    {
        $this->NbrTotal = $NbrTotal;

        return $this;
    }

    public function getNbrRestant(): ?int
    {
        return $this->NbrRestant;
    }

    public function setNbrRestant(int $NbrRestant): self
    {
        $this->NbrRestant = $NbrRestant;

        return $this;
    }

    public function getImage(): ?string
    {
        return $this->image;
    }

    public function setImage(string $image): self
    {
        $this->image = $image;

        return $this;
    }
}
